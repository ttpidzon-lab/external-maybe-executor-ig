import React, { useState, useEffect, useRef } from 'react';
import { Card, CardHeader } from './ui/Card';
import { Terminal as TerminalIcon, ChevronRight } from 'lucide-react';

const INITIAL_LOGS = [
  { type: 'info', msg: 'System initialized. Kernel v5.15.0-76-generic' },
  { type: 'info', msg: 'Connecting to game server instance: US-EAST-1...' },
  { type: 'success', msg: 'Connection established. Handshake successful.' },
  { type: 'warning', msg: 'Resource usage spike detected in Zone_B' },
  { type: 'info', msg: 'Awaiting developer input...' },
];

export default function Console() {
  const [logs, setLogs] = useState(INITIAL_LOGS);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const newLogs = [...logs, { type: 'command', msg: `> ${input}` }];
    
    // Simple command handling simulation
    if (input.toLowerCase() === 'clear') {
      setLogs([]);
    } else if (input.toLowerCase() === 'help') {
      newLogs.push({ type: 'info', msg: 'Available commands: clear, help, status, reload, kick [id], ban [id]' });
    } else {
      newLogs.push({ type: 'error', msg: `Unknown command: '${input}'. Type 'help' for list.` });
    }

    setLogs(newLogs);
    setInput('');
  };

  return (
    <Card className="flex flex-col h-[400px]">
      <CardHeader title="Developer Console" subtitle="Direct kernel access" />
      <div 
        ref={scrollRef}
        className="flex-1 p-4 font-mono text-xs overflow-y-auto space-y-1 bg-[#0A0A0A]"
      >
        {logs.map((log, i) => (
          <div key={i} className={
            log.type === 'error' ? 'text-red-500' : 
            log.type === 'warning' ? 'text-orange-500' : 
            log.type === 'success' ? 'text-emerald-500' : 
            log.type === 'command' ? 'text-white' : 
            'text-[#888]'
          }>
            {log.msg}
          </div>
        ))}
      </div>
      <form onSubmit={handleCommand} className="p-2 bg-[#1A1A1A] border-t border-[#333] flex items-center gap-2">
        <ChevronRight size={14} className="text-[#555]" />
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter command..."
          className="flex-1 bg-transparent border-none outline-none text-xs font-mono text-white placeholder-[#444]"
        />
        <TerminalIcon size={14} className="text-[#555]" />
      </form>
    </Card>
  );
}
