import { useState } from 'react';
import { Card, CardHeader } from './ui/Card';
import { Sun, Wind, Move, Zap } from 'lucide-react';

export default function WorldControls() {
  const [gravity, setGravity] = useState(9.8);
  const [time, setTime] = useState(1200);
  const [speed, setSpeed] = useState(1.0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card>
        <CardHeader title="Physics Engine" subtitle="Global constants" />
        <div className="p-4 space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-[10px] font-mono uppercase text-[#888]">
              <span>Gravity Multiplier</span>
              <span className="text-emerald-500">{gravity}m/s²</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="20" 
              step="0.1" 
              value={gravity}
              onChange={(e) => setGravity(parseFloat(e.target.value))}
              className="w-full h-1 bg-[#333] rounded-lg appearance-none cursor-pointer accent-emerald-500" 
            />
          </div>
          <div className="flex gap-2">
            <button className="flex-1 py-2 bg-[#252525] border border-[#333] text-[10px] font-mono uppercase hover:bg-[#333] transition-colors">Reset</button>
            <button className="flex-1 py-2 bg-[#252525] border border-[#333] text-[10px] font-mono uppercase hover:bg-[#333] transition-colors">Zero-G</button>
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader title="Environment" subtitle="Atmospheric settings" />
        <div className="p-4 space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-[10px] font-mono uppercase text-[#888]">
              <span>Time of Day</span>
              <span className="text-emerald-500">{Math.floor(time/100)}:{(time%100).toString().padStart(2, '0')}</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="2400" 
              step="10" 
              value={time}
              onChange={(e) => setTime(parseInt(e.target.value))}
              className="w-full h-1 bg-[#333] rounded-lg appearance-none cursor-pointer accent-emerald-500" 
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button className="py-2 bg-[#252525] border border-[#333] text-[10px] font-mono uppercase flex items-center justify-center gap-2 hover:bg-[#333]"><Sun size={12}/> Day</button>
            <button className="py-2 bg-[#252525] border border-[#333] text-[10px] font-mono uppercase flex items-center justify-center gap-2 hover:bg-[#333]"><Wind size={12}/> Night</button>
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader title="Game Speed" subtitle="Simulation rate" />
        <div className="p-4 space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-[10px] font-mono uppercase text-[#888]">
              <span>Time Scale</span>
              <span className="text-emerald-500">{speed}x</span>
            </div>
            <input 
              type="range" 
              min="0.1" 
              max="5.0" 
              step="0.1" 
              value={speed}
              onChange={(e) => setSpeed(parseFloat(e.target.value))}
              className="w-full h-1 bg-[#333] rounded-lg appearance-none cursor-pointer accent-emerald-500" 
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button className="py-2 bg-[#252525] border border-[#333] text-[10px] font-mono uppercase flex items-center justify-center gap-2 hover:bg-[#333]"><Move size={12}/> Normal</button>
            <button className="py-2 bg-[#252525] border border-[#333] text-[10px] font-mono uppercase flex items-center justify-center gap-2 hover:bg-[#333] text-red-500"><Zap size={12}/> Freeze</button>
          </div>
        </div>
      </Card>
    </div>
  );
}
