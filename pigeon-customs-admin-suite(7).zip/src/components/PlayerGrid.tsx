import { MoreHorizontal, Shield, User, Zap, Ban, Trash2, Crosshair } from 'lucide-react';
import { Card, CardHeader } from './ui/Card';

const players = [
  { id: '001', name: 'Xenon_Dev', role: 'Admin', ping: '12ms', level: 99, status: 'Active', location: 'City_Center', coords: '45, 30, 0' },
  { id: '002', name: 'ShadowByte', role: 'Player', ping: '45ms', level: 42, status: 'Active', location: 'Wilderness', coords: '-20, 65, 0' },
  { id: '003', name: 'Glitch_Fixer', role: 'Moderator', ping: '22ms', level: 75, status: 'Idle', location: 'Main_Hub', coords: '10, -40, 0' },
  { id: '004', name: 'NoobMaster69', role: 'Player', ping: '110ms', level: 5, status: 'Active', location: 'Starter_Zone', coords: '-60, -10, 0' },
  { id: '005', name: 'CyberPunk_2077', role: 'Player', ping: '32ms', level: 88, status: 'Active', location: 'Neon_District', coords: '80, 15, 0' },
  { id: '006', name: 'Admin_Test', role: 'Admin', ping: '5ms', level: 100, status: 'Active', location: 'Dev_Room', coords: '0, 0, 0' },
];

export default function PlayerGrid() {
  return (
    <Card>
      <CardHeader title="Active Player Directory" subtitle={`${players.length} entities connected`} />
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-[#333] bg-[#222]">
              <th className="px-4 py-3 text-[10px] font-mono text-[#555] uppercase tracking-wider">ID</th>
              <th className="px-4 py-3 text-[10px] font-mono text-[#555] uppercase tracking-wider">Identity</th>
              <th className="px-4 py-3 text-[10px] font-mono text-[#555] uppercase tracking-wider">Privilege</th>
              <th className="px-4 py-3 text-[10px] font-mono text-[#555] uppercase tracking-wider">Coordinates</th>
              <th className="px-4 py-3 text-[10px] font-mono text-[#555] uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#333]">
            {players.map((player) => (
              <tr key={player.id} className="hover:bg-[#252525] transition-colors group">
                <td className="px-4 py-3 text-xs font-mono text-[#555]">{player.id}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-[#333] flex items-center justify-center">
                      <User size={12} className="text-[#888]" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">{player.name}</div>
                      <div className="text-[10px] text-[#555]">{player.location}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono uppercase tracking-tighter ${
                    player.role === 'Admin' ? 'bg-red-500/10 text-red-500' : 
                    player.role === 'Moderator' ? 'bg-blue-500/10 text-blue-500' : 
                    'bg-emerald-500/10 text-emerald-500'
                  }`}>
                    {player.role}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs font-mono text-[#888]">{player.coords}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button title="Locate on Radar" className="p-1 hover:text-blue-400 text-[#555]"><Crosshair size={14} /></button>
                    <button title="Teleport to Player" className="p-1 hover:text-emerald-500 text-[#555]"><Zap size={14} /></button>
                    <button title="Kick" className="p-1 hover:text-orange-500 text-[#555]"><Trash2 size={14} /></button>
                    <button title="Ban" className="p-1 hover:text-red-500 text-[#555]"><Ban size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
