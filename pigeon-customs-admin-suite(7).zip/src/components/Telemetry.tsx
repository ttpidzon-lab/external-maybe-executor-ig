import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Card, CardHeader } from './ui/Card';

const data = Array.from({ length: 20 }).map((_, i) => ({
  time: `${i}:00`,
  players: Math.floor(Math.random() * 500) + 1200,
  latency: Math.floor(Math.random() * 30) + 15,
  cpu: Math.floor(Math.random() * 40) + 20,
}));

export default function Telemetry() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card className="h-[300px]">
        <CardHeader title="Live Player Count" subtitle="Real-time session data" />
        <div className="p-4 h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorPlayers" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
              <XAxis dataKey="time" stroke="#555" fontSize={10} tickLine={false} axisLine={false} />
              <YAxis stroke="#555" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid #333', fontSize: '10px' }}
                itemStyle={{ color: '#10b981' }}
              />
              <Area type="monotone" dataKey="players" stroke="#10b981" fillOpacity={1} fill="url(#colorPlayers)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="h-[300px]">
        <CardHeader title="Server Latency (ms)" subtitle="Avg response time" />
        <div className="p-4 h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
              <XAxis dataKey="time" stroke="#555" fontSize={10} tickLine={false} axisLine={false} />
              <YAxis stroke="#555" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid #333', fontSize: '10px' }}
              />
              <Line type="stepAfter" dataKey="latency" stroke="#3b82f6" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
