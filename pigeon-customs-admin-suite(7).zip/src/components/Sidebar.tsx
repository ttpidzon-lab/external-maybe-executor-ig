import { 
  LayoutDashboard, 
  Users, 
  Globe, 
  Terminal, 
  Settings, 
  Activity,
  ShieldAlert
} from 'lucide-react';
import { cn } from '../lib/utils';

const navItems = [
  { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
  { id: 'players', icon: Users, label: 'Players' },
  { id: 'world', icon: Globe, label: 'World' },
  { id: 'console', icon: Terminal, label: 'Console' },
  { id: 'security', icon: ShieldAlert, label: 'Security' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

export default function Sidebar({ activeTab, setActiveTab }: { activeTab: string; setActiveTab: (id: string) => void }) {
  return (
    <div className="w-64 bg-[#141414] border-r border-[#333] flex flex-col h-full">
      <div className="p-6 border-b border-[#333]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded-sm flex items-center justify-center">
            <Activity size={20} className="text-black" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-white">GAMEDEV ADMIN</h1>
            <p className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest">v2.4.0-stable</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 py-4">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-6 py-3 text-sm transition-colors relative",
              activeTab === item.id 
                ? "text-white bg-[#252525]" 
                : "text-[#888] hover:text-white hover:bg-[#1A1A1A]"
            )}
          >
            {activeTab === item.id && (
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500" />
            )}
            <item.icon size={18} />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-[#333] bg-[#0A0A0A]">
        <div className="flex items-center gap-3 px-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] font-mono text-[#888] uppercase tracking-tighter">Server: US-EAST-1 (Online)</span>
        </div>
      </div>
    </div>
  );
}
