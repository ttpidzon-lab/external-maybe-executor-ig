import React from 'react';
import { cn } from '../../lib/utils';

export function ColorPicker({ color, onChange }: { color: string; onChange: (val: string) => void }) {
  return (
    <div className="relative group">
      <div 
        className="w-4 h-4 rounded-full border border-white/20 shadow-[0_0_10px_rgba(255,255,255,0.1)] cursor-pointer hover:scale-125 transition-all duration-300 hover:border-white/50" 
        style={{ backgroundColor: color }}
      />
      <input 
        type="color" 
        value={color} 
        onChange={(e) => onChange(e.target.value)}
        className="absolute inset-0 opacity-0 cursor-pointer"
      />
    </div>
  );
}

export function Switch({ label, checked, onChange, color, onColorChange }: { 
  label: string; 
  checked: boolean; 
  onChange: (val: boolean) => void; 
  color?: string;
  onColorChange?: (val: string) => void;
}) {
  return (
    <label className="flex items-center justify-between group cursor-pointer py-2.5 hover:bg-white/[0.03] px-3 rounded-lg transition-all duration-300 border border-transparent hover:border-white/10 hover:shadow-[0_0_20px_rgba(255,255,255,0.02)]">
      <span className="text-[11px] text-[#999] group-hover:text-white transition-colors uppercase tracking-[0.15em] font-bold">{label}</span>
      <div className="flex items-center gap-4">
        {color && onColorChange && <ColorPicker color={color} onChange={onColorChange} />}
        <div 
          onClick={(e) => { e.preventDefault(); onChange(!checked); }}
          className={cn(
            "w-10 h-5.5 rounded-full transition-all duration-500 relative flex items-center px-1 border shadow-inner",
            checked 
              ? "bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)] border-transparent shadow-[0_0_20px_rgba(255,255,255,0.15)]" 
              : "bg-[#050505] border-white/5"
          )}
        >
          <div className={cn(
            "w-3.5 h-3.5 rounded-full transition-all duration-500 shadow-xl",
            checked ? "translate-x-4.5 bg-black scale-110" : "translate-x-0 bg-[#222]"
          )} />
        </div>
      </div>
    </label>
  );
}

export function Slider({ label, value, min, max, step = 1, onChange, unit = "" }: { label: string; value: number; min: number; max: number; step?: number; onChange: (val: number) => void; unit?: string }) {
  return (
    <div className="space-y-3 py-3 group/slider px-3">
      <div className="flex justify-between items-center">
        <span className="text-[11px] text-[#999] group-hover/slider:text-white transition-colors uppercase tracking-[0.15em] font-bold">{label}</span>
        <span className="text-[11px] font-black tracking-tighter" style={{ color: 'var(--accent)' }}>{value}{unit}</span>
      </div>
      <div className="relative h-2 flex items-center">
        <input 
          type="range" 
          min={min} 
          max={max} 
          step={step} 
          value={value} 
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="w-full h-1 bg-[#050505] rounded-full appearance-none cursor-pointer accent-white hover:scale-[1.01] active:scale-[0.99] transition-all duration-300 border border-white/5"
          style={{
            background: `linear-gradient(to right, var(--accent) 0%, var(--accent-secondary) ${(value - min) / (max - min) * 100}%, #050505 ${(value - min) / (max - min) * 100}%, #050505 100%)`
          }}
        />
      </div>
    </div>
  );
}

export function Select({ label, options, value, onChange }: { label: string; options: string[]; value: string; onChange: (val: string) => void }) {
  return (
    <div className="space-y-2 py-2 group/select">
      <span className="text-[11px] text-[#888] group-hover/select:text-white transition-colors uppercase tracking-widest font-semibold block">{label}</span>
      <div className="relative">
        <select 
          value={value} 
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-[#0A0A0A] border border-white/10 text-[11px] text-white px-3 py-2 rounded-md outline-none focus:border-white/30 transition-all duration-300 appearance-none cursor-pointer hover:bg-[#111] hover:scale-[1.01] active:scale-[0.99] font-medium"
        >
          {options.map(opt => <option key={opt} value={opt} className="bg-[#0D0D0D]">{opt}</option>)}
        </select>
        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#444] text-[10px] transition-transform group-hover/select:translate-y-[-40%]">▼</div>
      </div>
    </div>
  );
}

export function Group({ title, icon: Icon, children }: { title: string; icon?: React.ElementType; children: React.ReactNode }) {
  return (
    <div className="space-y-6 bg-gradient-to-b from-white/[0.03] to-transparent backdrop-blur-xl p-6 rounded-xl border border-white/[0.05] relative overflow-hidden group/group hover:border-white/10 transition-all duration-700 hover:shadow-[0_0_40px_rgba(255,255,255,0.03)]">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[var(--accent)] to-transparent opacity-0 group-hover/group:opacity-40 transition-opacity duration-1000" />
      <div className="absolute bottom-0 right-0 w-32 h-32 bg-[var(--accent)]/5 blur-[60px] rounded-full pointer-events-none group-hover/group:bg-[var(--accent)]/10 transition-colors duration-1000" />
      
      <div className="flex items-center gap-4 border-b border-white/[0.05] pb-4 mb-2">
        <div className="p-2 rounded-lg bg-white/[0.02] border border-white/5 group-hover/group:bg-white/[0.05] group-hover/group:border-white/10 transition-all duration-500 group-hover/group:scale-110">
          {Icon && <Icon size={16} className="text-[#666] group-hover/group:text-white transition-colors duration-500" />}
        </div>
        <h4 className="text-[11px] text-[#444] group-hover/group:text-white font-black uppercase tracking-[0.3em] transition-colors duration-500">{title}</h4>
      </div>
      <div className="space-y-1 relative z-10">
        {children}
      </div>
    </div>
  );
}

export function Button({ label, onClick, variant = 'primary', className }: { label: string; onClick?: () => void; variant?: 'primary' | 'secondary' | 'danger'; className?: string }) {
  const variants = {
    primary: "bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)] text-black hover:opacity-90 shadow-[0_0_15px_rgba(255,255,255,0.1)]",
    secondary: "bg-[#0A0A0A] text-white border border-white/10 hover:bg-[#111] hover:border-white/20",
    danger: "bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20"
  };

  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full py-2.5 rounded-md text-[10px] font-black uppercase tracking-widest transition-all duration-300 active:scale-[0.97] shadow-lg",
        variants[variant],
        className
      )}
    >
      {label}
    </button>
  );
}

export function Input({ label, value, onChange, placeholder }: { label?: string; value: string; onChange: (val: string) => void; placeholder?: string }) {
  return (
    <div className="space-y-2 py-1 group/input">
      {label && <span className="text-[11px] text-[#888] group-hover/input:text-white transition-colors uppercase tracking-widest font-semibold block">{label}</span>}
      <input 
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-[#0A0A0A] border border-white/10 text-[11px] text-white px-3 py-2 rounded-md outline-none focus:border-white/30 transition-all duration-300 placeholder:text-[#333]"
      />
    </div>
  );
}
