import * as React from 'react';
import { cn } from '../../lib/utils';

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("bg-[#1A1A1A] border border-[#333] rounded-sm overflow-hidden", className)}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="px-4 py-2 border-bottom border-[#333] bg-[#252525] flex justify-between items-center">
      <h3 className="text-[11px] font-mono uppercase tracking-wider text-[#888]">{title}</h3>
      {subtitle && <span className="text-[10px] font-mono text-[#555] italic">{subtitle}</span>}
    </div>
  );
}
