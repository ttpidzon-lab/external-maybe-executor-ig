import React, { useState, useEffect } from 'react';
import { Card, CardHeader } from './ui/Card';
import { Crosshair, Maximize2, Minimize2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface Entity {
  id: string;
  name: string;
  x: number;
  y: number;
  role: string;
}

const INITIAL_ENTITIES: Entity[] = [
  { id: '001', name: 'Xenon_Dev', x: 45, y: 30, role: 'Admin' },
  { id: '002', name: 'ShadowByte', x: -20, y: 65, role: 'Player' },
  { id: '003', name: 'Glitch_Fixer', x: 10, y: -40, role: 'Moderator' },
  { id: '004', name: 'NoobMaster69', x: -60, y: -10, role: 'Player' },
  { id: '005', name: 'CyberPunk_2077', x: 80, y: 15, role: 'Player' },
];

export default function SpatialRadar() {
  const [entities, setEntities] = useState<Entity[]>(INITIAL_ENTITIES);
  const [zoom, setZoom] = useState(1);
  const [hoveredEntity, setHoveredEntity] = useState<Entity | null>(null);

  // Simulate slight movement
  useEffect(() => {
    const interval = setInterval(() => {
      setEntities(prev => prev.map(e => ({
        ...e,
        x: e.x + (Math.random() - 0.5) * 2,
        y: e.y + (Math.random() - 0.5) * 2,
      })));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="relative flex flex-col h-[400px] overflow-hidden">
      <CardHeader title="Live Spatial Radar" subtitle="Real-time entity positioning" />
      
      <div className="flex-1 bg-[#0A0A0A] relative overflow-hidden cursor-crosshair group">
        {/* Grid Lines */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" 
             style={{ 
               backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)',
               backgroundSize: `${40 * zoom}px ${40 * zoom}px`,
               backgroundPosition: 'center'
             }} 
        />
        
        {/* Axis Lines */}
        <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-emerald-500/20 pointer-events-none" />
        <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-emerald-500/20 pointer-events-none" />

        {/* Entities */}
        <div className="absolute inset-0 flex items-center justify-center">
          {entities.map((entity) => (
            <div
              key={entity.id}
              className="absolute transition-all duration-1000 ease-linear"
              style={{
                left: `calc(50% + ${entity.x * zoom}px)`,
                top: `calc(50% - ${entity.y * zoom}px)`,
              }}
              onMouseEnter={() => setHoveredEntity(entity)}
              onMouseLeave={() => setHoveredEntity(null)}
            >
              <div className={cn(
                "w-3 h-3 rounded-full border-2 border-[#0A0A0A] shadow-lg cursor-pointer transition-transform hover:scale-150",
                entity.role === 'Admin' ? 'bg-red-500' : 
                entity.role === 'Moderator' ? 'bg-blue-500' : 'bg-emerald-500'
              )} />
              
              {/* ESP Label Style */}
              <div className={cn(
                "absolute top-4 left-1/2 -translate-x-1/2 whitespace-nowrap pointer-events-none transition-opacity",
                hoveredEntity?.id === entity.id ? "opacity-100" : "opacity-0 group-hover:opacity-40"
              )}>
                <div className="bg-[#1A1A1A]/90 border border-[#333] px-1.5 py-0.5 rounded text-[9px] font-mono">
                  <span className="text-white font-bold">{entity.name}</span>
                  <span className="text-[#555] ml-1">[{Math.round(entity.x)}, {Math.round(entity.y)}]</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Radar Controls */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <button 
            onClick={() => setZoom(prev => Math.min(prev + 0.2, 3))}
            className="p-2 bg-[#1A1A1A] border border-[#333] text-[#888] hover:text-white rounded-sm"
          >
            <Maximize2 size={14} />
          </button>
          <button 
            onClick={() => setZoom(prev => Math.max(prev - 0.2, 0.5))}
            className="p-2 bg-[#1A1A1A] border border-[#333] text-[#888] hover:text-white rounded-sm"
          >
            <Minimize2 size={14} />
          </button>
        </div>

        {/* Legend */}
        <div className="absolute top-4 left-4 flex flex-col gap-1">
          <div className="flex items-center gap-2 text-[9px] font-mono text-[#555] uppercase">
            <div className="w-2 h-2 rounded-full bg-red-500" /> Admin
          </div>
          <div className="flex items-center gap-2 text-[9px] font-mono text-[#555] uppercase">
            <div className="w-2 h-2 rounded-full bg-blue-500" /> Moderator
          </div>
          <div className="flex items-center gap-2 text-[9px] font-mono text-[#555] uppercase">
            <div className="w-2 h-2 rounded-full bg-emerald-500" /> Player
          </div>
        </div>
      </div>

      {/* Selected Entity Info */}
      <div className="h-12 bg-[#141414] border-t border-[#333] flex items-center px-4 justify-between">
        <div className="flex items-center gap-2">
          <Crosshair size={14} className="text-emerald-500" />
          <span className="text-[10px] font-mono text-[#888] uppercase tracking-widest">Target:</span>
          <span className="text-xs font-bold text-white">{hoveredEntity ? hoveredEntity.name : 'NONE'}</span>
        </div>
        {hoveredEntity && (
          <div className="text-[10px] font-mono text-emerald-500">
            LOC: {Math.round(hoveredEntity.x)}X, {Math.round(hoveredEntity.y)}Y, 0Z
          </div>
        )}
      </div>
    </Card>
  );
}
