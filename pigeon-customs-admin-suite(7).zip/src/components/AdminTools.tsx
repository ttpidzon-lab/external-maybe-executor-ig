import React, { useState } from 'react';
import { Card, CardHeader } from './ui/Card';
import { Plane, Ghost, ShieldCheck, EyeOff, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

interface AdminToolsProps {
  onToggle: (tool: string, state: boolean) => void;
}

export default function AdminTools({ onToggle }: AdminToolsProps) {
  const [states, setStates] = useState({
    fly: false,
    noclip: false,
    godmode: false,
    stealth: false,
  });

  const handleToggle = (key: keyof typeof states) => {
    const newState = !states[key];
    setStates(prev => ({ ...prev, [key]: newState }));
    onToggle(key as string, newState);
  };

  const tools = [
    { id: 'fly', label: 'Fly Mode', icon: Plane, color: 'text-blue-400', desc: 'Enable vertical movement' },
    { id: 'noclip', label: 'NoClip', icon: Ghost, color: 'text-purple-400', desc: 'Bypass all collisions' },
    { id: 'godmode', label: 'God Mode', icon: ShieldCheck, color: 'text-yellow-400', desc: 'Infinite health/stamina' },
    { id: 'stealth', label: 'Invisibility', icon: EyeOff, color: 'text-emerald-400', desc: 'Hidden from entity radar' },
  ];

  return (
    <Card>
      <CardHeader title="Admin Privilege Suite" subtitle="Movement & State Overrides" />
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {tools.map((tool) => {
          const isActive = states[tool.id as keyof typeof states];
          return (
            <button
              key={tool.id}
              onClick={() => handleToggle(tool.id as keyof typeof states)}
              className={cn(
                "flex items-center gap-4 p-3 border transition-all text-left group",
                isActive 
                  ? "bg-[#252525] border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.1)]" 
                  : "bg-[#1A1A1A] border-[#333] hover:border-[#444]"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-sm flex items-center justify-center transition-colors",
                isActive ? "bg-emerald-500 text-black" : "bg-[#252525] text-[#555] group-hover:text-[#888]"
              )}>
                <tool.icon size={20} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className={cn("text-xs font-bold uppercase tracking-wider", isActive ? "text-white" : "text-[#888]")}>
                    {tool.label}
                  </span>
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full",
                    isActive ? "bg-emerald-500 animate-pulse" : "bg-[#333]"
                  )} />
                </div>
                <p className="text-[10px] font-mono text-[#555] mt-0.5">{tool.desc}</p>
              </div>
            </button>
          );
        })}
      </div>
      <div className="px-4 py-2 bg-[#0A0A0A] border-t border-[#333] flex items-center justify-between">
        <span className="text-[9px] font-mono text-[#444] uppercase">Kernel Authorization: GRANTED</span>
        <Zap size={10} className="text-emerald-500" />
      </div>
    </Card>
  );
}
