# Pigeon-Customs C++ Integration Guide

This guide explains how to bundle this React application into a standalone C++ application using a lightweight webview.

## Prerequisites

1.  **Node.js & npm**: To build the React project.
2.  **C++ Compiler**: GCC, Clang, or MSVC.
3.  **Webview Library**: We recommend [webview/webview](https://github.com/webview/webview), a tiny cross-platform library.

## Step 1: Build the React Project

Run the following command in the project root to generate the static files:

```bash
npm run build
```

This will create a `dist` folder containing `index.html`, CSS, and JS files.

## Step 2: C++ Implementation

Create a file named `main.cpp`. This example uses the `webview.h` header-only library.

### Minimal C++ Code (`main.cpp`)

```cpp
#include "webview.h"
#include <iostream>
#include <string>
#include <filesystem>

#ifdef _WIN32
#include <Windows.h>
#endif

int main() {
    // 1. Create the webview window
    webview::webview w(true, nullptr);
    w.set_title("Pigeon-Customs Premium");
    w.set_size(900, 650, WEBVIEW_HINT_NONE);

    // 2. Load the built application
    // In a real app, you would bundle the dist folder or serve it locally.
    // For development, you can point to the dev server:
    // w.navigate("http://localhost:3000");
    
    // For production, point to the absolute path of index.html:
    std::string path = std::filesystem::current_path().string() + "/dist/index.html";
    w.navigate("file://" + path);

    // 3. Bridge C++ and JavaScript (Universal Injection)
    // This allows the React UI to send scripts to your C++ injector
    w.bind("executeScript", [](std::string script, std::string language) -> std::string {
        std::cout << "Injecting " << language << " script..." << std::endl;
        
        // --- YOUR INJECTION LOGIC HERE ---
        // 1. Find the game process (RobloxPlayerBeta.exe)
        // 2. Open process handle
        // 3. Allocate memory and write the script
        // 4. Call your internal Lua/Luau execution function
        // ---------------------------------
        
        return "Script Injected";
    });

    w.run();
    return 0;
}
```

## Step 3: Compilation

### Windows (MSVC)
```bash
cl /I. main.cpp /link /OUT:PigeonCustoms.exe
```

### Linux (GCC)
```bash
g++ main.cpp -o PigeonCustoms `pkg-config --cflags --libs gtk+-3.0 webkit2gtk-4.0`
```

### macOS (Clang)
```bash
clang++ main.cpp -framework WebKit -o PigeonCustoms
```

## Why C++?

-   **Performance**: Extremely low overhead compared to Electron.
-   **Security**: You can implement hardware-level checks (HWID) directly in C++.
-   **Integration**: Easily call native system APIs or game memory functions.

## Script Executor Features

The built-in script executor now supports:
-   **GitHub/Pastebin**: Automatically resolves raw URLs.
-   **Lua/Luau**: Integrated `wasmoon` VM for client-side Lua execution.
-   **Console**: Real-time logging of `print()` calls from Lua.
