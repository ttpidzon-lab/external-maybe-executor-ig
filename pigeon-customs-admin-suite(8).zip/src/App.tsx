import React, { useState, useEffect } from 'react';
import { Switch, Slider, Select, Group, ColorPicker, Button, Input } from './components/ui/VainUI';
import { LuaFactory } from 'wasmoon';
import { 
  Activity,
  Zap,
  Target,
  Eye,
  Globe,
  User,
  Settings,
  Users,
  Shield,
  Ghost,
  Plane,
  Crosshair,
  Terminal,
  Server,
  Camera,
  MapPin,
  Sun,
  MousePointer2,
  Search,
  Map as MapIcon
} from 'lucide-react';
import { cn } from './lib/utils';

type Tab = 'Combat' | 'Visuals' | 'World' | 'Character' | 'Options' | 'Players' | 'NPC' | 'Servers';
type NPCTab = 'Rivals' | 'Abyss [BETA]' | 'Hypershot';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('Visuals');
  const [activeNPCTab, setActiveNPCTab] = useState<NPCTab>('Rivals');
  const [onlineCount, setOnlineCount] = useState(4421);
  const [isAppOpen, setIsAppOpen] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  
  // Theme State
  const [accentColor, setAccentColor] = useState('#FFFFFF');
  const [accentSecondary, setAccentSecondary] = useState('#000000');
  const [menuOpacity, setMenuOpacity] = useState(98);
  const [fontFamily, setFontFamily] = useState('Inter');
  
  // Script Executor State
  const [script, setScript] = useState('-- Pigeon-Customs Executor\nprint("Hello World")');
  const [scriptUrl, setScriptUrl] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [executorLanguage, setExecutorLanguage] = useState('Lua');
  const [executorLogs, setExecutorLogs] = useState<string[]>([]);

  const handleExecute = async () => {
    setIsExecuting(true);
    setExecutorLogs(prev => [...prev, `[${executorLanguage}] Executing...`]);
    
    try {
      // 1. Check for Native Bridge (C++ Wrapper)
      // This is what actually injects into the game
      if ((window as any).executeScript) {
        setExecutorLogs(prev => [...prev, `[NATIVE] Sending to game engine...`]);
        await (window as any).executeScript(script, executorLanguage);
        setExecutorLogs(prev => [...prev, `[SUCCESS] Injected successfully.`]);
      } 
      // 2. Fallback to Internal VM for testing/simulation
      else if (executorLanguage === 'Lua' || executorLanguage === 'Luau') {
        const factory = new LuaFactory();
        const lua = await factory.createEngine();
        
        lua.global.set('print', (...args: any[]) => {
          const msg = args.map(a => String(a)).join(' ');
          setExecutorLogs(prev => [...prev, `[PRINT] ${msg}`]);
        });

        // Universal Game Environment Mock
        lua.global.set('game', {
          Players: {
            LocalPlayer: { Character: { Humanoid: { Health: 100 } } },
            GetPlayers: () => players.map(p => ({ Name: p.name }))
          },
          Workspace: { CurrentCamera: { FieldOfView: 70 } }
        });

        await lua.doString(script);
        setExecutorLogs(prev => [...prev, `[SUCCESS] Internal VM execution finished.`]);
      } else {
        eval(script);
        setExecutorLogs(prev => [...prev, `[SUCCESS] JS execution finished.`]);
      }
    } catch (err: any) {
      setExecutorLogs(prev => [...prev, `[ERROR] ${err.message}`]);
    } finally {
      setIsExecuting(false);
    }
  };

  const loadScriptFromUrl = async () => {
    if (!scriptUrl) return;
    
    let targetUrl = scriptUrl;
    
    // Handle Pastebin
    if (scriptUrl.includes('pastebin.com/') && !scriptUrl.includes('/raw/')) {
      targetUrl = scriptUrl.replace('pastebin.com/', 'pastebin.com/raw/');
    }
    
    // Handle GitHub
    if (scriptUrl.includes('github.com/') && !scriptUrl.includes('raw.githubusercontent.com')) {
      targetUrl = scriptUrl.replace('github.com/', 'raw.githubusercontent.com/').replace('/blob/', '/');
    }

    try {
      setExecutorLogs(prev => [...prev, `[FETCH] Loading from ${targetUrl}...`]);
      const response = await fetch(targetUrl);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const text = await response.text();
      setScript(text);
      setExecutorLogs(prev => [...prev, `[FETCH] Successfully loaded script.`]);
    } catch (err: any) {
      setExecutorLogs(prev => [...prev, `[FETCH ERROR] ${err.message}`]);
    }
  };

  // Visuals State
  const [esp, setEsp] = useState({
    enabled: true,
    teamCheck: false,
    visibleCheck: true,
    visibleColor: '#3b82f6',
    invisibleColor: '#ef4444',
    distance: 3000,
    box: true,
    boxColor: '#FFFFFF',
    boxType: '3D Box',
    names: true,
    tracers: false,
    radar: true,
    userMap: false,
    chams: true,
    chamsFill: 'Glitch'
  });

  // Combat State
  const [combat, setCombat] = useState({
    aimbot: false,
    silentAim: false,
    fov: 90,
    smoothing: 5,
    priority: 'Distance',
    hitbox: 'Head',
    noRecoil: true,
    noSpread: true,
    rapidFire: false,
    targetHovering: {
      enabled: false,
      radius: 100,
      speed: 5,
      fov: 90
    }
  });

  // World State
  const [world, setWorld] = useState({
    gravity: 9.8,
    timeScale: 1.0,
    timeOfDay: 1200,
    noFog: true,
    fullBright: true,
    weather: 'Clear',
    camera: {
      thirdPerson: false,
      fovEnabled: false,
      fovAmount: 70
    },
    waypoint: {
      name: '',
      waypoints: ['Waypoint 1'],
      selectedWaypoint: 'Waypoint 1',
      tweenGoto: false,
      tweenSpeed: 200,
      visualize: false
    },
    lighting: {
      ambience: true,
      ambienceColor: '#8B5CF6',
      customFog: true,
      fogColor: '#FFFFFF',
      glow: false,
      distance: 100000,
      customExposure: true,
      exposure: -0.52,
      customBrightness: true,
      brightness: 0,
      customTime: true,
      clockTime: 10.93,
      customSky: true,
      skyType: 'Emerald Nocturne'
    },
    freecam: {
      enabled: false,
      keybind: 'xbutton2',
      teleportOnClick: false,
      tpKeybind: 'n',
      lockPosition: false,
      speed: 1.5
    }
  });

  // Character State
  const [char, setChar] = useState({
    fly: false,
    noclip: false,
    infJump: true,
    speed: 1.0,
    godMode: true,
    stealth: false
  });

  // Players State
  const [players, setPlayers] = useState([
    { id: '10280465884', name: 'FrancessPUGE', tag: 'Friend', priority: 'Friendly' },
    { id: '001', name: 'BurgerSniffer3000', tag: 'Client', priority: 'Neutral' },
    { id: '002', name: 'Andrew12345_GG', tag: '?', priority: 'Neutral' },
    { id: '003', name: 'Ammar_aqil2211', tag: '?', priority: 'Neutral' },
    { id: '004', name: 'milo_loveultraphone', tag: '?', priority: 'Neutral' },
    { id: '005', name: 'FERRANN_44', tag: 'Target', priority: 'Enemy' },
    { id: '006', name: 'yaneporus', tag: '?', priority: 'Neutral' },
    { id: '007', name: 'Raka_1723536', tag: '?', priority: 'Neutral' },
    { id: '008', name: 'nexusnaellll', tag: '?', priority: 'Neutral' },
    { id: '009', name: 'mashamain2', tag: '?', priority: 'Neutral' },
    { id: '010', name: 'Champion_game70', tag: '?', priority: 'Neutral' },
    { id: '011', name: 'Tuessdayss', tag: '?', priority: 'Neutral' },
    { id: '012', name: 'ploby13', tag: '?', priority: 'Neutral' },
    { id: '013', name: 'MrDoDouu', tag: '?', priority: 'Neutral' },
  ]);
  const [selectedPlayerId, setSelectedPlayerId] = useState('10280465884');
  const [playerSearch, setPlayerSearch] = useState('');

  const selectedPlayer = players.find(p => p.id === selectedPlayerId) || players[0];

  // NPC Settings State
  const [npcSettings, setNpcSettings] = useState({
    Rivals: { silentAim: false, autoKill: false, autoSpawn: false, autoTp: false, tpua: false, tpOut: false },
    'Abyss [BETA]': { silentAim: false, autoKill: false, autoSpawn: false, autoTp: false, tpua: false, tpOut: false },
    Hypershot: { silentAim: false, autoKill: false, autoSpawn: false, autoTp: false, tpua: false, tpOut: false },
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setOnlineCount(prev => prev + Math.floor(Math.random() * 5) - 2);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const tabs: Tab[] = ['Combat', 'Visuals', 'World', 'Character', 'Options', 'Players', 'NPC', 'Servers'];

  return (
    <div 
      className="flex items-center justify-center min-h-screen p-4"
      style={{ 
        '--accent': accentColor, 
        '--accent-secondary': accentSecondary,
        '--font-family': fontFamily 
      } as React.CSSProperties}
    >
      {/* Entry Button */}
      {!isAppOpen && !showWelcome && (
        <div className="relative group animate-float">
          <div className="absolute -inset-1 bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)] rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <button 
            onClick={() => setShowWelcome(true)}
            className="relative px-12 py-5 bg-[#0D0D0D] border border-white/10 text-white font-bold uppercase tracking-[0.3em] transition-all hover:scale-110 active:scale-95 shadow-2xl overflow-hidden group/btn"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent)]/10 to-[var(--accent-secondary)]/10 opacity-0 group-hover/btn:opacity-100 transition-opacity" />
            <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)] transform scale-x-0 group-hover/btn:scale-x-100 transition-transform duration-500 origin-left" />
            <span className="relative z-10 drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]">Open Pigeon-Customs</span>
          </button>
        </div>
      )}

      {/* Welcome Warning */}
      {showWelcome && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md animate-in fade-in duration-500">
          <div className="bg-[#0D0D0D] border border-white/10 p-8 rounded-lg shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col items-center gap-6 text-center max-w-sm relative overflow-hidden group/warning">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)]" />
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center border border-white/10 group-hover/warning:border-[var(--accent)] transition-colors duration-500">
              <Shield size={32} className="text-white group-hover/warning:text-[var(--accent)] transition-colors duration-500" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold uppercase tracking-tighter text-white">System Notification</h2>
              <p className="text-xs text-[#888] leading-relaxed">Pigeon-customs opened! Welcome!</p>
            </div>
            <button 
              onClick={() => {
                setShowWelcome(false);
                setIsAppOpen(true);
              }}
              className="w-full py-3 bg-white text-black text-[11px] font-black uppercase tracking-widest hover:bg-[var(--accent)] transition-all active:scale-95 shadow-lg"
            >
              Ok!
            </button>
          </div>
        </div>
      )}

      {/* Main Window */}
      {isAppOpen && (
        <>
          <div 
            className="w-[850px] h-[600px] bg-[#0D0D0D] border border-white/10 rounded-xl shadow-[0_0_100px_rgba(0,0,0,0.8)] flex flex-col overflow-hidden relative animate-blur-in backdrop-blur-2xl"
            style={{ opacity: menuOpacity / 100 }}
          >
            {/* Scanline Effect */}
            <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,0.03),rgba(0,255,0,0.01),rgba(0,0,255,0.03))] bg-[length:100%_2px,3px_100%] z-50 opacity-20" />
            
            {/* Vignette */}
            <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_150px_rgba(0,0,0,0.9)] z-40" />
        
        {/* Header */}
        <div className="h-14 border-b border-[#222] flex items-center justify-between px-6 bg-[#111]">
          <div className="flex items-center gap-3">
            <div className="flex flex-col">
              <span className="text-sm font-bold tracking-tighter text-white uppercase">Pigeon <span className="text-[10px] text-[var(--accent)] font-normal ml-1 uppercase">Customs</span></span>
              <span className="text-[9px] text-[#444] uppercase tracking-widest leading-none">Administrative Interface</span>
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex items-center gap-1">
            {tabs.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-3 py-1.5 text-[11px] font-medium uppercase tracking-tight transition-all rounded-sm hover:scale-105 active:scale-95",
                  activeTab === tab 
                    ? "text-white bg-[#1A1A1A]" 
                    : "text-[#666] hover:text-[#AAA]"
                )}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden flex">
          <div className="flex-1 p-6 overflow-y-auto grid grid-cols-2 gap-8">
            
            {activeTab === 'Visuals' && (
              <>
                <div className="space-y-8">
                  <Group title="ESP" icon={Eye}>
                    <Switch label="Enabled" checked={esp.enabled} onChange={(v) => setEsp({...esp, enabled: v})} />
                    <Switch label="Team Check" checked={esp.teamCheck} onChange={(v) => setEsp({...esp, teamCheck: v})} />
                    <Switch 
                      label="Visible Check" 
                      checked={esp.visibleCheck} 
                      onChange={(v) => setEsp({...esp, visibleCheck: v})} 
                      color={esp.visibleColor}
                      onColorChange={(c) => setEsp({...esp, visibleColor: c})}
                    />
                    <Switch 
                      label="Invisible Color" 
                      checked={true} 
                      onChange={() => {}} 
                      color={esp.invisibleColor}
                      onColorChange={(c) => setEsp({...esp, invisibleColor: c})}
                    />
                    <Slider label="Render Distance" value={esp.distance} min={100} max={5000} step={100} onChange={(v) => setEsp({...esp, distance: v})} unit="m" />
                  </Group>

                  <Group title="Box" icon={Target}>
                    <Switch 
                      label="Enabled" 
                      checked={esp.box} 
                      onChange={(v) => setEsp({...esp, box: v})} 
                      color={esp.boxColor}
                      onColorChange={(c) => setEsp({...esp, boxColor: c})}
                    />
                    <Select label="Box Type" options={['2D Box', '3D Box', 'Corner Box']} value={esp.boxType} onChange={(v) => setEsp({...esp, boxType: v})} />
                  </Group>
                </div>

                <div className="space-y-8">
                  <Group title="Chams" icon={Zap}>
                    <Switch label="Enabled" checked={esp.chams} onChange={(v) => setEsp({...esp, chams: v})} />
                    <Select label="Fill Type" options={['Solid', 'Glitch', 'Wireframe', 'Pulse']} value={esp.chamsFill} onChange={(v) => setEsp({...esp, chamsFill: v})} />
                  </Group>

                  <Group title="Misc Visuals" icon={Activity}>
                    <Switch label="Tracers" checked={esp.tracers} onChange={(v) => setEsp({...esp, tracers: v})} />
                    <Switch label="Radar" checked={esp.radar} onChange={(v) => setEsp({...esp, radar: v})} />
                    <div className="flex items-center justify-between py-2.5 hover:bg-white/[0.03] px-3 rounded-lg transition-all duration-300 border border-transparent hover:border-white/10">
                      <span className="text-[11px] text-[#999] group-hover:text-white transition-colors uppercase tracking-[0.15em] font-bold">User Map</span>
                      <button 
                        onClick={() => setEsp({...esp, userMap: !esp.userMap})}
                        className={cn(
                          "px-4 py-1.5 rounded-md text-[9px] font-black uppercase tracking-widest transition-all duration-300",
                          esp.userMap ? "bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)] text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]" : "bg-white/5 text-[#444] border border-white/10"
                        )}
                      >
                        {esp.userMap ? "ON" : "OFF"}
                      </button>
                    </div>
                    <Select label="Font" options={['ProggyClean', 'Inter', 'JetBrains', 'Verdana']} value="ProggyClean" onChange={() => {}} />
                  </Group>
                </div>
              </>
            )}

            {activeTab === 'Combat' && (
              <>
                <div className="space-y-8">
                  <Group title="Aimbot" icon={Target}>
                    <Switch label="Enabled" checked={combat.aimbot} onChange={(v) => setCombat({...combat, aimbot: v})} />
                    <Switch label="Silent Aim" checked={combat.silentAim} onChange={(v) => setCombat({...combat, silentAim: v})} />
                    <Slider label="FOV" value={combat.fov} min={1} max={180} onChange={(v) => setCombat({...combat, fov: v})} unit="°" />
                    <Slider label="Smoothing" value={combat.smoothing} min={1} max={20} onChange={(v) => setCombat({...combat, smoothing: v})} />
                  </Group>
                  <Group title="Targeting" icon={Crosshair}>
                    <Select label="Priority" options={['Distance', 'FOV', 'Health']} value={combat.priority} onChange={(v) => setCombat({...combat, priority: v})} />
                    <Select label="Hitbox" options={['Head', 'Neck', 'Chest', 'Pelvis']} value={combat.hitbox} onChange={(v) => setCombat({...combat, hitbox: v})} />
                  </Group>
                </div>
                <div className="space-y-8">
                  <Group title="Target Hovering" icon={Activity}>
                    <Switch label="Enabled" checked={combat.targetHovering.enabled} onChange={(v) => setCombat({...combat, targetHovering: {...combat.targetHovering, enabled: v}})} />
                    <Slider label="Radius" value={combat.targetHovering.radius} min={10} max={500} onChange={(v) => setCombat({...combat, targetHovering: {...combat.targetHovering, radius: v}})} unit="px" />
                    <Slider label="Speed" value={combat.targetHovering.speed} min={1} max={20} onChange={(v) => setCombat({...combat, targetHovering: {...combat.targetHovering, speed: v}})} />
                    <Slider label="FOV" value={combat.targetHovering.fov} min={10} max={180} onChange={(v) => setCombat({...combat, targetHovering: {...combat.targetHovering, fov: v}})} unit="°" />
                  </Group>
                  <Group title="Weapon" icon={Zap}>
                    <Switch label="No Recoil" checked={combat.noRecoil} onChange={(v) => setCombat({...combat, noRecoil: v})} />
                    <Switch label="No Spread" checked={combat.noSpread} onChange={(v) => setCombat({...combat, noSpread: v})} />
                    <Switch label="Rapid Fire" checked={combat.rapidFire} onChange={(v) => setCombat({...combat, rapidFire: v})} />
                  </Group>
                </div>
              </>
            )}

            {activeTab === 'World' && (
              <>
                <div className="space-y-8">
                  <Group title="Camera" icon={Camera}>
                    <Switch label="Third Person" checked={world.camera.thirdPerson} onChange={(v) => setWorld({...world, camera: {...world.camera, thirdPerson: v}})} />
                    <Switch label="Camera Field Of View" checked={world.camera.fovEnabled} onChange={(v) => setWorld({...world, camera: {...world.camera, fovEnabled: v}})} />
                    <Slider label="Amount" value={world.camera.fovAmount} min={30} max={120} onChange={(v) => setWorld({...world, camera: {...world.camera, fovAmount: v}})} />
                  </Group>
                  <Group title="Waypoint" icon={MapPin}>
                    <Input label="Name" value={world.waypoint.name} onChange={(v) => setWorld({...world, waypoint: {...world.waypoint, name: v}})} placeholder="Waypoint Name" />
                    <Button label="Create" onClick={() => {}} />
                    <Select label="Waypoints" options={world.waypoint.waypoints} value={world.waypoint.selectedWaypoint} onChange={(v) => setWorld({...world, waypoint: {...world.waypoint, selectedWaypoint: v}})} />
                    <div className="grid grid-cols-2 gap-2">
                      <Button label="Remove Waypoint" variant="secondary" onClick={() => {}} />
                      <Button label="Goto" variant="secondary" onClick={() => {}} />
                    </div>
                    <Switch label="Tween goto" checked={world.waypoint.tweenGoto} onChange={(v) => setWorld({...world, waypoint: {...world.waypoint, tweenGoto: v}})} />
                    <Slider label="Tween speed" value={world.waypoint.tweenSpeed} min={10} max={1000} step={10} onChange={(v) => setWorld({...world, waypoint: {...world.waypoint, tweenSpeed: v}})} />
                    <Switch label="Visualize waypoint" checked={world.waypoint.visualize} onChange={(v) => setWorld({...world, waypoint: {...world.waypoint, visualize: v}})} />
                  </Group>
                </div>
                <div className="space-y-8">
                  <Group title="World Lighting" icon={Sun}>
                    <Switch 
                      label="Ambience" 
                      checked={world.lighting.ambience} 
                      onChange={(v) => setWorld({...world, lighting: {...world.lighting, ambience: v}})} 
                      color={world.lighting.ambienceColor}
                      onColorChange={(c) => setWorld({...world, lighting: {...world.lighting, ambienceColor: c}})}
                    />
                    <Switch 
                      label="Custom Fog" 
                      checked={world.lighting.customFog} 
                      onChange={(v) => setWorld({...world, lighting: {...world.lighting, customFog: v}})} 
                      color={world.lighting.fogColor}
                      onColorChange={(c) => setWorld({...world, lighting: {...world.lighting, fogColor: c}})}
                    />
                    <Switch label="Glow" checked={world.lighting.glow} onChange={(v) => setWorld({...world, lighting: {...world.lighting, glow: v}})} />
                    <Slider label="Distance" value={world.lighting.distance} min={0} max={200000} step={1000} onChange={(v) => setWorld({...world, lighting: {...world.lighting, distance: v}})} />
                    <Switch label="Custom Exposure" checked={world.lighting.customExposure} onChange={(v) => setWorld({...world, lighting: {...world.lighting, customExposure: v}})} />
                    <Slider label="Exposure Compensation" value={world.lighting.exposure} min={-2} max={2} step={0.01} onChange={(v) => setWorld({...world, lighting: {...world.lighting, exposure: v}})} />
                    <Switch label="Custom Brightness" checked={world.lighting.customBrightness} onChange={(v) => setWorld({...world, lighting: {...world.lighting, customBrightness: v}})} />
                    <Slider label="Brightness" value={world.lighting.brightness} min={-1} max={1} step={0.01} onChange={(v) => setWorld({...world, lighting: {...world.lighting, brightness: v}})} />
                    <Switch label="Custom Time" checked={world.lighting.customTime} onChange={(v) => setWorld({...world, lighting: {...world.lighting, customTime: v}})} />
                    <Slider label="Clock Time" value={world.lighting.clockTime} min={0} max={24} step={0.01} onChange={(v) => setWorld({...world, lighting: {...world.lighting, clockTime: v}})} />
                    <Switch label="Custom Sky" checked={world.lighting.customSky} onChange={(v) => setWorld({...world, lighting: {...world.lighting, customSky: v}})} />
                    <Select label="Sky" options={['Emerald Nocturne', 'Midnight', 'Noon', 'Sunset']} value={world.lighting.skyType} onChange={(v) => setWorld({...world, lighting: {...world.lighting, skyType: v}})} />
                  </Group>
                  <Group title="Freecam" icon={MousePointer2}>
                    <div className="flex items-center justify-between py-1">
                      <Switch label="Enabled" checked={world.freecam.enabled} onChange={(v) => setWorld({...world, freecam: {...world.freecam, enabled: v}})} />
                      <span className="text-[10px] text-[#444] bg-white/5 px-1.5 py-0.5 rounded border border-white/10">{world.freecam.keybind}</span>
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <Switch label="Teleport on click" checked={world.freecam.teleportOnClick} onChange={(v) => setWorld({...world, freecam: {...world.freecam, teleportOnClick: v}})} />
                      <span className="text-[10px] text-[#444] bg-white/5 px-1.5 py-0.5 rounded border border-white/10">{world.freecam.tpKeybind}</span>
                    </div>
                    <Switch label="Lock Character Position" checked={world.freecam.lockPosition} onChange={(v) => setWorld({...world, freecam: {...world.freecam, lockPosition: v}})} />
                    <Slider label="Speed" value={world.freecam.speed} min={0.1} max={10} step={0.1} onChange={(v) => setWorld({...world, freecam: {...world.freecam, speed: v}})} />
                  </Group>
                </div>
              </>
            )}

            {activeTab === 'Character' && (
              <>
                <div className="space-y-8">
                  <Group title="Movement" icon={Plane}>
                    <Switch label="Fly" checked={char.fly} onChange={(v) => setChar({...char, fly: v})} />
                    <Switch label="NoClip" checked={char.noclip} onChange={(v) => setChar({...char, noclip: v})} />
                    <Switch label="Infinite Jump" checked={char.infJump} onChange={(v) => setChar({...char, infJump: v})} />
                    <Slider label="Speed Multiplier" value={char.speed} min={1} max={10} step={0.1} onChange={(v) => setChar({...char, speed: v})} unit="x" />
                  </Group>
                </div>
                <div className="space-y-8">
                  <Group title="State" icon={Shield}>
                    <Switch label="God Mode" checked={char.godMode} onChange={(v) => setChar({...char, godMode: v})} />
                    <Switch label="Stealth Mode" checked={char.stealth} onChange={(v) => setChar({...char, stealth: v})} />
                  </Group>
                </div>
              </>
            )}

            {activeTab === 'Options' && (
              <>
                <div className="space-y-8">
                  <Group title="Menu Customization" icon={Settings}>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-[11px] text-[#BBB] uppercase tracking-tight font-medium">Primary Color</span>
                      <ColorPicker color={accentColor} onChange={setAccentColor} />
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-[11px] text-[#BBB] uppercase tracking-tight font-medium">Secondary Color</span>
                      <ColorPicker color={accentSecondary} onChange={setAccentSecondary} />
                    </div>
                    <Select 
                      label="Font Family" 
                      options={['Inter', 'Space Grotesk', 'Outfit', 'JetBrains Mono', 'Playfair Display', 'Anton', 'Bangers', 'Montserrat', 'Roboto', 'Syncopate', 'Michroma']} 
                      value={fontFamily} 
                      onChange={setFontFamily} 
                    />
                    <Slider label="Menu Opacity" value={menuOpacity} min={50} max={100} onChange={setMenuOpacity} unit="%" />
                  </Group>
                  <Group title="Premium" icon={Zap}>
                    <div className="p-3 bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20 rounded-sm">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] text-amber-500 font-bold uppercase tracking-tight">Pigeon-Customs Premium</span>
                        <span className="text-[11px] text-white">$6 Lifetime</span>
                      </div>
                      <button className="w-full py-2 bg-amber-500 text-black text-[10px] font-bold uppercase hover:bg-amber-400 transition-all hover:scale-[1.02] active:scale-[0.98]">
                        Purchase Now
                      </button>
                    </div>
                  </Group>
                  <Group title="Configuration" icon={Terminal}>
                    <button className="w-full py-2 bg-[#1A1A1A] border border-[#222] text-[10px] uppercase hover:bg-[#222] transition-colors">Save Config</button>
                    <button className="w-full py-2 bg-[#1A1A1A] border border-[#222] text-[10px] uppercase hover:bg-[#222] transition-colors mt-2">Load Config</button>
                    <button className="w-full py-2 bg-[#1A1A1A] border border-[#222] text-[10px] uppercase hover:bg-[#222] transition-colors mt-2">Reset HWID</button>
                    <button className="w-full py-2 bg-red-500/10 border border-red-500/20 text-[10px] uppercase text-red-500 hover:bg-red-500/20 transition-colors mt-2">Reset All</button>
                  </Group>
                </div>
                <div className="space-y-8">
                  <Group title="Script Executor" icon={Terminal}>
                    <div className="space-y-3">
                      <div className="flex gap-2">
                        <div className="flex-1">
                          <Input 
                            placeholder="GitHub / Pastebin URL" 
                            value={scriptUrl} 
                            onChange={setScriptUrl} 
                          />
                        </div>
                        <button 
                          onClick={loadScriptFromUrl}
                          className="px-4 py-2 bg-[#1A1A1A] border border-[#222] text-[10px] uppercase hover:bg-[#222] transition-all rounded-md"
                        >
                          Load URL
                        </button>
                      </div>

                      <div className="flex gap-2 items-center">
                        <div className="flex-1">
                          <Select 
                            label="Language" 
                            options={['Lua', 'Luau', 'JavaScript']} 
                            value={executorLanguage} 
                            onChange={setExecutorLanguage} 
                          />
                        </div>
                        <div className="text-right flex flex-col items-end">
                          <span className="text-[10px] font-black text-emerald-500/50 uppercase tracking-[0.2em] animate-pulse">167% sUNC</span>
                          <span className="text-[8px] text-blue-400 font-bold uppercase tracking-widest">Universal Mode</span>
                        </div>
                      </div>

                      <textarea 
                        value={script}
                        onChange={(e) => setScript(e.target.value)}
                        className="w-full h-48 bg-[#0A0A0A] border border-[#222] rounded-sm p-3 text-[11px] font-mono text-emerald-500 outline-none focus:border-[var(--accent)] transition-colors resize-none"
                        spellCheck={false}
                      />

                      <div className="h-24 bg-black/50 border border-white/5 rounded-sm p-2 overflow-y-auto custom-scrollbar font-mono text-[9px]">
                        {executorLogs.map((log, i) => (
                          <div key={i} className={cn(
                            "py-0.5",
                            log.includes('[ERROR]') ? "text-red-400" : 
                            log.includes('[SUCCESS]') ? "text-emerald-400" : 
                            log.includes('[FETCH]') ? "text-blue-400" : "text-white/40"
                          )}>
                            {log}
                          </div>
                        ))}
                        {executorLogs.length === 0 && <div className="text-white/10 italic">Console output will appear here...</div>}
                      </div>

                      <div className="flex gap-2">
                        <button 
                          onClick={handleExecute}
                          disabled={isExecuting}
                          className={cn(
                            "flex-1 py-2 text-[10px] uppercase transition-all border rounded-md",
                            isExecuting 
                              ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-500 animate-pulse" 
                              : "bg-[var(--accent)] border-[var(--accent)] text-black hover:opacity-90 active:scale-95"
                          )}
                        >
                          {isExecuting ? "Executing..." : "Run Script"}
                        </button>
                        <button 
                          onClick={() => { setScript(''); setExecutorLogs([]); }}
                          className="px-4 py-2 bg-[#1A1A1A] border border-[#222] text-[10px] uppercase hover:bg-[#222] transition-colors rounded-md"
                        >
                          Clear
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => setScript('print("Hello from Pigeon-Customs!")\nprint("LocalPlayer Health: " .. game.Players.LocalPlayer.Character.Humanoid.Health)')}
                          className="py-1.5 bg-[#111] border border-[#222] text-[9px] uppercase text-[#666] hover:text-white hover:border-[#444] transition-all rounded-md"
                        >
                          Test Script
                        </button>
                        <button 
                          onClick={() => setScript('for i,v in pairs(game.Players:GetPlayers()) do\n  print("Player: " .. v.Name)\nend')}
                          className="py-1.5 bg-[#111] border border-[#222] text-[9px] uppercase text-[#666] hover:text-white hover:border-[#444] transition-all rounded-md"
                        >
                          List Players
                        </button>
                      </div>
                    </div>
                  </Group>
                </div>
              </>
            )}

            {activeTab === 'NPC' && (
              <div className="col-span-2 space-y-6">
                {/* NPC Sub-tabs */}
                <div className="flex items-center gap-2 border-b border-[#222] pb-2">
                  {(['Rivals', 'Abyss [BETA]', 'Hypershot'] as NPCTab[]).map(tab => (
                    <button
                      key={tab}
                      onClick={() => setActiveNPCTab(tab)}
                      className={cn(
                        "px-4 py-1.5 text-[10px] font-bold uppercase tracking-widest transition-all rounded-sm border",
                        activeNPCTab === tab 
                          ? "text-white bg-[#1A1A1A] border-[var(--accent)]" 
                          : "text-[#555] border-transparent hover:text-[#888]"
                      )}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-8">
                    <Group title="NPC Config" icon={Settings}>
                      <Switch 
                        label="Silent Aim" 
                        checked={npcSettings[activeNPCTab].silentAim} 
                        onChange={(v) => setNpcSettings({...npcSettings, [activeNPCTab]: {...npcSettings[activeNPCTab], silentAim: v}})} 
                      />
                      <Switch 
                        label="Autokill" 
                        checked={npcSettings[activeNPCTab].autoKill} 
                        onChange={(v) => setNpcSettings({...npcSettings, [activeNPCTab]: {...npcSettings[activeNPCTab], autoKill: v}})} 
                      />
                      <Switch 
                        label="Autospawn" 
                        checked={npcSettings[activeNPCTab].autoSpawn} 
                        onChange={(v) => setNpcSettings({...npcSettings, [activeNPCTab]: {...npcSettings[activeNPCTab], autoSpawn: v}})} 
                      />
                    </Group>
                  </div>
                  <div className="space-y-8">
                    <Group title="Teleportation" icon={Globe}>
                      <Switch 
                        label="Auto TP" 
                        checked={npcSettings[activeNPCTab].autoTp} 
                        onChange={(v) => setNpcSettings({...npcSettings, [activeNPCTab]: {...npcSettings[activeNPCTab], autoTp: v}})} 
                      />
                      <Switch 
                        label="TPUA" 
                        checked={npcSettings[activeNPCTab].tpua} 
                        onChange={(v) => setNpcSettings({...npcSettings, [activeNPCTab]: {...npcSettings[activeNPCTab], tpua: v}})} 
                      />
                      <Switch 
                        label="TP Out" 
                        checked={npcSettings[activeNPCTab].tpOut} 
                        onChange={(v) => setNpcSettings({...npcSettings, [activeNPCTab]: {...npcSettings[activeNPCTab], tpOut: v}})} 
                      />
                    </Group>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'Servers' && (
              <div className="col-span-2">
                <Group title="Server List" icon={Server}>
                  <div className="bg-[#111] border border-[#222] rounded-sm overflow-hidden">
                    <table className="w-full text-left text-[11px]">
                      <thead className="bg-[#1A1A1A] text-[#555] uppercase font-bold">
                        <tr>
                          <th className="px-4 py-2">Region</th>
                          <th className="px-4 py-2">Players</th>
                          <th className="px-4 py-2">Ping</th>
                          <th className="px-4 py-2">Status</th>
                          <th className="px-4 py-2">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#222]">
                        {[
                          { region: 'US-East (Virginia)', players: '12/20', ping: '24ms', status: 'Optimal' },
                          { region: 'EU-West (London)', players: '18/20', ping: '82ms', status: 'High Load' },
                          { region: 'US-West (Oregon)', players: '4/20', ping: '45ms', status: 'Optimal' },
                          { region: 'Asia (Tokyo)', players: '20/20', ping: '160ms', status: 'Full' },
                          { region: 'South America (Brazil)', players: '9/20', ping: '110ms', status: 'Optimal' },
                        ].map((s, i) => (
                          <tr key={i} className="hover:bg-[#1A1A1A] transition-colors group">
                            <td className="px-4 py-2 text-white font-medium">{s.region}</td>
                            <td className="px-4 py-2 text-[#888]">{s.players}</td>
                            <td className="px-4 py-2 font-mono text-emerald-500">{s.ping}</td>
                            <td className="px-4 py-2">
                              <span className={cn(
                                "px-1.5 py-0.5 rounded-[2px] text-[9px] uppercase font-bold",
                                s.status === 'Optimal' ? "bg-emerald-500/10 text-emerald-500" : 
                                s.status === 'Full' ? "bg-red-500/10 text-red-500" : "bg-yellow-500/10 text-yellow-500"
                              )}>{s.status}</span>
                            </td>
                            <td className="px-4 py-2">
                              <button className="text-[var(--accent)] hover:underline hover:scale-105 active:scale-95 transition-transform">JOIN</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Group>
              </div>
            )}

            {activeTab === 'Players' && (
              <div className="col-span-2 grid grid-cols-[1fr_300px] gap-6 h-full overflow-hidden">
                {/* Player List */}
                <div className="bg-[#0A0A0A]/80 border border-white/[0.03] rounded-lg flex flex-col overflow-hidden">
                  <div className="p-4 border-b border-white/[0.05] flex items-center justify-between">
                    <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-white">Players [{players.length}]</h3>
                  </div>
                  <div className="p-3">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#444]" />
                      <input 
                        type="text" 
                        placeholder="Search player..."
                        value={playerSearch}
                        onChange={(e) => setPlayerSearch(e.target.value)}
                        className="w-full bg-[#111] border border-white/[0.05] rounded-md py-2 pl-10 pr-4 text-[11px] text-white outline-none focus:border-white/20 transition-all"
                      />
                    </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
                    {players.filter(p => p.name.toLowerCase().includes(playerSearch.toLowerCase())).map(player => (
                      <button
                        key={player.id}
                        onClick={() => setSelectedPlayerId(player.id)}
                        className={cn(
                          "w-full flex items-center justify-between px-4 py-2.5 rounded-md transition-all group",
                          selectedPlayerId === player.id 
                            ? "bg-white/[0.05] border border-white/10" 
                            : "hover:bg-white/[0.02] border border-transparent"
                        )}
                      >
                        <span className={cn(
                          "text-[11px] font-bold transition-colors",
                          selectedPlayerId === player.id ? "text-white" : "text-[#666] group-hover:text-[#AAA]"
                        )}>{player.name}</span>
                        <span className={cn(
                          "text-[9px] font-black uppercase px-2 py-0.5 rounded-[3px]",
                          player.tag === 'Client' ? "bg-blue-500/10 text-blue-500" :
                          player.tag === 'Friend' ? "bg-emerald-500/10 text-emerald-500" :
                          player.tag === 'Target' ? "bg-red-500/10 text-red-500" :
                          "bg-white/5 text-[#444]"
                        )}>{player.tag}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Selected Player Details */}
                <div className="space-y-6 overflow-y-auto custom-scrollbar">
                  <Group title="Selected Player" icon={User}>
                    <div className="flex flex-col items-center py-4 space-y-3">
                      <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 overflow-hidden relative group/avatar">
                        <img 
                          src={`https://picsum.photos/seed/${selectedPlayer.id}/200/200`} 
                          alt="Avatar" 
                          className="w-full h-full object-cover group-hover/avatar:scale-110 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover/avatar:opacity-100 transition-opacity" />
                      </div>
                      <div className="text-center">
                        <h4 className="text-sm font-black text-white uppercase tracking-tight">{selectedPlayer.name}</h4>
                        <p className="text-[9px] text-[#444] font-mono">User ID: {selectedPlayer.id}</p>
                      </div>
                    </div>
                    <Select 
                      label="Priority" 
                      options={['Friendly', 'Neutral', 'Enemy', 'Target']} 
                      value={selectedPlayer.priority} 
                      onChange={() => {}} 
                    />
                  </Group>

                  <Group title="Actions" icon={Zap}>
                    <div className="grid grid-cols-2 gap-2">
                      <Button label="Teleport" variant="secondary" />
                      <Button label="Spectate" variant="secondary" />
                      <Button label="Unspectate" variant="secondary" />
                      <Button label="Fling" variant="secondary" />
                    </div>
                  </Group>
                </div>
              </div>
            )}

          </div>
        </div>

        {/* Footer */}
        <div className="h-10 border-t border-[#222] bg-[#080808] flex items-center justify-between px-4 text-[9px] text-[#444] uppercase tracking-widest">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5">
              <div className="w-1 h-1 rounded-full bg-[var(--accent)] accent-glow" />
              <span className="text-white">{onlineCount} online</span>
            </div>
            <span className="text-[var(--accent)]">PIGEON-CUSTOMS.STORE</span>
            
            {/* User Profile Widget */}
            <div className="flex items-center gap-3 bg-[#111] px-3 py-1 rounded-sm border border-[#222] ml-2">
              <div className="w-6 h-6 rounded-full bg-[#222] overflow-hidden border border-white/10">
                <img 
                  src="https://picsum.photos/seed/pigeon/100/100" 
                  alt="Avatar" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-[10px] text-white font-bold tracking-tight">pigeon-customising</span>
                <span className="text-[8px] text-[#555]">@pigeon-customising</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span>status: <span className="text-[var(--accent)] text-glow">Undetected</span></span>
          </div>
        </div>

        {/* Floating Accents */}
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[var(--accent)] to-transparent opacity-50" />
      </div>

      {/* Keybind List Widget */}
      <div className="fixed bottom-32 right-8 pointer-events-none opacity-60">
        <div className="bg-black/80 backdrop-blur-md border border-white/5 p-3 rounded-sm shadow-2xl w-48">
          <div className="flex items-center gap-2 mb-2 border-b border-white/5 pb-1">
            <Target size={12} className="text-[var(--accent)]" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-white">Keybind List</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[10px]">
              <span className="text-[#888]">ESP</span>
              <span className="text-[var(--accent)]">NONE</span>
            </div>
            <div className="flex justify-between text-[10px]">
              <span className="text-[#888]">Silent Aim</span>
              <span className="text-[var(--accent)]">E</span>
            </div>
            <div className="flex justify-between text-[10px]">
              <span className="text-[#888]">Fly</span>
              <span className="text-[var(--accent)]">F</span>
            </div>
          </div>
        </div>
      </div>

      {/* Radar Widget (User Map) */}
      {isAppOpen && esp.userMap && (
        <div className="fixed top-8 left-8 w-72 h-72 pointer-events-none animate-in fade-in slide-in-from-left-8 duration-700 z-[60]">
          <div className="w-full h-full bg-black/90 backdrop-blur-3xl border border-white/10 rounded-2xl relative overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)]">
            {/* Radar Header */}
            <div className="absolute top-0 left-0 w-full p-4 flex items-center justify-between border-b border-white/5 bg-white/[0.02] z-10">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-blue-500/20 border border-blue-500/30">
                  <MapIcon size={14} className="text-blue-400" />
                </div>
                <span className="text-[11px] font-black uppercase tracking-[0.2em] text-white">Radar</span>
              </div>
              <span className="text-[10px] font-mono text-[#444] font-bold">11</span>
            </div>
            
            <div className="absolute inset-0 flex items-center justify-center pt-10">
              {/* Radar Circles */}
              <div className="w-56 h-56 border border-white/5 rounded-full flex items-center justify-center relative">
                <div className="w-40 h-40 border border-white/5 rounded-full flex items-center justify-center">
                  <div className="w-24 h-24 border border-white/5 rounded-full" />
                </div>
                
                {/* Crosshair Lines */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-full h-[1px] bg-white/[0.03]" />
                  <div className="w-[1px] h-full bg-white/[0.03]" />
                </div>

                {/* Compass Labels */}
                <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-black text-[#333] tracking-widest">N</span>
                <span className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] font-black text-[#333] tracking-widest">S</span>
                <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-black text-[#333] tracking-widest">W</span>
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-black text-[#333] tracking-widest">E</span>

                {/* Center Point */}
                <div className="w-2 h-2 bg-white rounded-full shadow-[0_0_15px_white] z-20" />

                {/* Entities (Avatars) */}
                <div className="absolute top-[15%] left-[30%] w-9 h-9 rounded-full border-2 border-white/20 bg-black shadow-lg flex items-center justify-center overflow-hidden hover:scale-110 transition-transform">
                   <img src="https://picsum.photos/seed/p1/50/50" alt="p" className="w-full h-full object-cover opacity-80" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute top-[40%] left-[15%] w-9 h-9 rounded-full border-2 border-emerald-500/40 bg-black shadow-lg flex items-center justify-center overflow-hidden hover:scale-110 transition-transform">
                   <img src="https://picsum.photos/seed/p2/50/50" alt="p" className="w-full h-full object-cover opacity-80" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute bottom-[20%] right-[25%] w-9 h-9 rounded-full border-2 border-red-500/40 bg-black shadow-lg flex items-center justify-center overflow-hidden hover:scale-110 transition-transform">
                   <img src="https://picsum.photos/seed/p3/50/50" alt="p" className="w-full h-full object-cover opacity-80" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute top-[25%] right-[20%] w-9 h-9 rounded-full border-2 border-blue-500/40 bg-black shadow-lg flex items-center justify-center overflow-hidden hover:scale-110 transition-transform">
                   <img src="https://picsum.photos/seed/p4/50/50" alt="p" className="w-full h-full object-cover opacity-80" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>

            {/* Scan Line Animation */}
            <div className="absolute inset-0 bg-gradient-to-t from-blue-500/20 via-blue-500/5 to-transparent h-1/2 w-full animate-scanline pointer-events-none z-30" />
            
            {/* Grid Overlay */}
            <div className="absolute inset-0 pointer-events-none opacity-5 bg-[radial-gradient(#fff_1px,transparent_1px)] bg-[length:20px_20px]" />
          </div>
        </div>
      )}
    </>
    )}
    </div>
  );
}
